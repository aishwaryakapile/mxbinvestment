import React from 'react'
import './termsandcondtn.css'
import { Row, Container } from 'react-bootstrap';
const Termsandcondtnheader = () => {
    return (
        <>
            <section className='termsandcondtnheader-section'>
                <Container>
                    <Row>
                        <h1 className='Termsandcondtnheader-heading'>Terms and conditions</h1>
                    </Row>
                </Container>
            </section>
        </>
    )
}

export default Termsandcondtnheader