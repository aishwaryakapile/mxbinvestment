import React from 'react'
import Termsandcondtnheader from '../component/Termsandcondtnheader'
import TermsAndConditonComp from '../component/TermsAndConditonComp'

const TermsAndCondition = () => {
  return (
    <>
<Termsandcondtnheader/>
<TermsAndConditonComp/>
    </>
  )
}

export default TermsAndCondition